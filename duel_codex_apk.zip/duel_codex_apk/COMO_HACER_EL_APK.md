# Cómo obtener el APK de Duel Codex

No necesitas instalar nada en tu computadora. GitHub compila el APK por ti, gratis,
con el archivo `.github/workflows/build-apk.yml` que ya viene en esta carpeta.
Todo se hace desde el navegador. Tarda unos 10 minutos la primera vez.

## 1. Crea tu cuenta y tu repositorio

1. Entra a `github.com` y crea una cuenta (si ya tienes, inicia sesión).
2. Arriba a la derecha toca **+** y luego **New repository**.
3. Nombre: `duel-codex`. Puede ser Public o Private. Toca **Create repository**.

## 2. Sube los archivos

1. En el repositorio nuevo toca el enlace **uploading an existing file**.
2. Abre esta carpeta (`duel_codex_apk`) en tu computadora y selecciona **todo su contenido**
   (no la carpeta en sí): `www`, `assets`, `package.json`, `capacitor.config.json`,
   `.gitignore` y `.github`. Arrástralo a la página.
3. Espera a que termine de subir y toca **Commit changes**.

**Importante:** `.github` es una carpeta oculta. Si no la ves en el Explorador, activa
Ver → Mostrar → Elementos ocultos. Si después de subir no aparece en el repositorio,
créala a mano: toca **Add file → Create new file**, escribe como nombre
`.github/workflows/build-apk.yml` y pega dentro el contenido de ese archivo.

## 3. Deja que se compile

1. Entra a la pestaña **Actions** del repositorio. Si te pide permiso, toca
   **I understand my workflows, go ahead and enable them**.
2. Ahí verás una ejecución llamada **Compilar APK** en marcha (círculo amarillo).
   Si no apareció, toca **Compilar APK** a la izquierda y luego **Run workflow**.
3. Espera a que quede con la palomita verde.

## 4. Descarga el APK

1. Toca la ejecución terminada.
2. Abajo, en **Artifacts**, toca **Duel-Codex-APK**. Se descarga un zip.
3. Descomprímelo: adentro está `app-debug.apk`.

## 5. Instálalo en tu Android

1. Pasa el archivo al celular (cable USB, Google Drive o WhatsApp a ti mismo).
2. Ábrelo desde el celular. Android te pedirá permiso para **instalar apps de esta fuente**:
   actívalo para esa app (Archivos, Chrome o WhatsApp, según desde dónde lo abriste).
3. Si Play Protect muestra un aviso de app no verificada, toca **Instalar de todas formas**.
   Sale porque es un APK de prueba, no está en Play Store.

Un APK solo funciona en Android. En iPhone usa la versión web instalable (PWA).

## Si algo falla

- Si la ejecución sale con una X roja, tócala, toca el paso que quedó en rojo y copia el
  mensaje de error. Mándaselo a Claude y lo corrige.
- Si el paso **Poner el ícono y la pantalla de inicio** sale en amarillo o rojo, el APK se
  genera igual, pero con el ícono por defecto de Capacitor.

## Para cambiar la app después

Edita o sube de nuevo los archivos de la carpeta `www` en GitHub. Cada cambio que
guardes (commit) compila un APK nuevo automáticamente.

## Qué contiene cada cosa

```
www/                          La app (la misma versión web de Duel Codex)
assets/                       Ícono y pantalla de inicio de la app de Android
capacitor.config.json         Nombre y datos de la app (com.duelcodex.app)
package.json                  Herramienta que convierte la web en app (Capacitor)
.github/workflows/build-apk.yml   Las instrucciones para que GitHub compile el APK
```

## Notas

- Este APK es de **prueba** (debug): sirve para instalarlo en tu celular y mostrarlo.
  Para subirlo a Google Play habría que firmarlo con una llave propia.
- Las cuentas, decks y perfil se guardan dentro de cada teléfono. No hay servidor.
- Las imágenes de las cartas y los datos necesitan internet.
- YGOPRODeck pide no cargar imágenes directamente de su servidor en una versión pública:
  antes de publicarla más allá de tu clase, descárgalas y alójalas tú.
